package pkgMain;

public class Model {

	private double x = 100;
	private double y = 200;
	private final double LEFT = 700;
	private final double RIGHT=0;
	private final double BOTTOM = 500;
	private final double TOP=0;
	
	public double getX() {
		return x;
	}
	public void setX(double d) {
		if(x>100) {
			this.x = Math.min(d, LEFT);
		}
		else {
			this.x=Math.max(d, RIGHT);
		}
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		if(this.y>100) {
			this.y = Math.min(y, BOTTOM);
		}
		else {
			this.y=Math.max(y, TOP);
		}
	}
	
	
}
