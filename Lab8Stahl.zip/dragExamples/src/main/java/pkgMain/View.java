package pkgMain;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;



public class View extends Application {

	private Controller imc;
	private ImageView iv1;
	private final double WIDTH = 800;
	private final double HEIGHT = 600;
	TilePane tile = new TilePane();
	FlowPane flow = new FlowPane();
	StackPane stack=new StackPane();
	ArrayList<ImageView> imgArr;
	Image im1;
	double plantSize = 100;
	int xDelay=0;
	
	public View(){
    	iv1 = new ImageView();
		imc = new Controller(this);
		imgArr = new ArrayList<ImageView>();
	}
		
    @Override
    public void start(Stage stage) {
    	
    	Image im1 = new Image(getClass().getResourceAsStream("/img/commonMilkweed.png"));
    	iv1.setImage(im1);
    	iv1.setPreserveRatio(true);
    	iv1.setFitHeight(100);
    	iv1.setOnMouseDragged(imc.getHandlerForDrag());
    	iv1.setOnMouseReleased(imc.getHandlerForRelease());
    	
    	tile.getChildren().add(iv1);
    	StackPane stack=new StackPane();
    	stack.getChildren().add(flow);
    	stack.getChildren().add(tile);
    	Scene scene = new Scene(stack, WIDTH, HEIGHT);
        stage.setScene(scene);

        stage.show();
    }
    public void setX(double x) {
    	iv1.setTranslateX(x);
    }
    public void setY(double y) {
    	iv1.setTranslateY(y);
    }
    
    public int createImg(double x,double y) {
    	ImageView view = new ImageView();
    	
    	view.setImage(new Image(getClass().getResourceAsStream("/img/commonMilkweed.png")));
    	view.setPreserveRatio(true);
    	view.setFitHeight(plantSize);
    	view.setTranslateX(x-xDelay);
    	view.setTranslateY(y);
    	flow.getChildren().add(view);
    	xDelay+=100;
    	return 0;
    	
    }
    
    public static void main(String[] args) {
        launch();
    }

}
