package pkgMain;

import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class Controller {

	private final boolean DEBUG = true;
	View view;
	Model model;
	
	Controller(View view){
		this.view = view;
		model = new Model();
		if (DEBUG) System.out.println("ic created");
	}
	
	public void drag(MouseEvent event) {
		Node n = (Node)event.getSource();
		if (DEBUG) System.out.println("ic mouse drag tx: " + n.getTranslateX() + ", ex: " + event.getX() );
		model.setX(model.getX() + event.getX());
		model.setY(model.getY() + event.getY());
		view.setX( model.getX() );
		view.setY( model.getY() );
	}
	public void release(MouseEvent event) {
		
		view.createImg(model.getX(),model.getY());
		model.setX(0);
		model.setY(0);
		view.setX(model.getX());
		view.setY(model.getY());
	}
	public EventHandler getHandlerForDrag() {
		return event -> drag((MouseEvent) event);
	}
	public EventHandler getHandlerForRelease() {
		return event -> release((MouseEvent) event);
	}

	public double getStartingX() {
		return model.getX();
	}
	public double getStartingY() {
		return model.getY();
	}
	
	
}