module JavaFXHello {
	
	
	exports pkgMain;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	
}